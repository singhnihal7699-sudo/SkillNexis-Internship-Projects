// ==================== DIGITAL CLOCK ====================

// DOM Elements for Clock
const timeDisplay = document.getElementById('timeDisplay');
const dateDisplay = document.getElementById('dateDisplay');

// Function to format time with leading zeros
function formatTime(num) {
    return num < 10 ? '0' + num : num;
}

// Function to update the digital clock
function updateClock() {
    const now = new Date();

    // Get time components
    const hours = formatTime(now.getHours());
    const minutes = formatTime(now.getMinutes());
    const seconds = formatTime(now.getSeconds());

    // Update time display
    timeDisplay.textContent = `${hours}:${minutes}:${seconds}`;

    // Get date components
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June',
                   'July', 'August', 'September', 'October', 'November', 'December'];

    const dayName = days[now.getDay()];
    const monthName = months[now.getMonth()];
    const date = now.getDate();
    const year = now.getFullYear();

    dateDisplay.textContent = `${dayName}, ${monthName} ${date}, ${year}`;
}

// Update clock immediately and then every 1000ms (1 second)
updateClock();
setInterval(updateClock, 1000);

// ==================== COUNTDOWN TIMER ====================

// DOM Elements for Countdown
const daysElement = document.getElementById('days');
const hoursElement = document.getElementById('hours');
const minutesElement = document.getElementById('minutes');
const secondsElement = document.getElementById('seconds');
const countdownStatus = document.getElementById('countdownStatus');

// Function to update countdown timer
function updateCountdown() {
    // Target date: Tomorrow at midnight (August 31, 2026, 00:00:00)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const targetDate = tomorrow.getTime();
    const now = new Date().getTime();
    const difference = targetDate - now;

    // If countdown is finished
    if (difference <= 0) {
        daysElement.textContent = '0';
        hoursElement.textContent = '0';
        minutesElement.textContent = '0';
        secondsElement.textContent = '0';
        countdownStatus.textContent = '🎉 Tomorrow is here! 🎉';
        countdownStatus.style.color = '#00ff88';
        return;
    }

    // Calculate time units
    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((difference % (1000 * 60)) / 1000);

    // Update display with leading zeros
    daysElement.textContent = formatTime(days);
    hoursElement.textContent = formatTime(hours);
    minutesElement.textContent = formatTime(minutes);
    secondsElement.textContent = formatTime(seconds);

    // Update status message
    if (days > 0) {
        countdownStatus.textContent = `${days} day${days > 1 ? 's' : ''} remaining until tomorrow!`;
    } else if (hours > 0) {
        countdownStatus.textContent = `${hours} hour${hours > 1 ? 's' : ''} remaining until tomorrow!`;
    } else if (minutes > 0) {
        countdownStatus.textContent = `${minutes} minute${minutes > 1 ? 's' : ''} remaining until tomorrow!`;
    } else {
        countdownStatus.textContent = `${seconds} second${seconds > 1 ? 's' : ''} remaining until tomorrow!`;
    }
    countdownStatus.style.color = 'rgba(255, 255, 255, 0.9)';
}

// Update countdown immediately and then every 1000ms (1 second)
updateCountdown();
setInterval(updateCountdown, 1000);

// ==================== SIMPLE TIMER ====================

// DOM Elements for Simple Timer
const timerMinutesInput = document.getElementById('timerMinutes');
const timerSecondsInput = document.getElementById('timerSeconds');
const startTimerBtn = document.getElementById('startTimerBtn');
const stopTimerBtn = document.getElementById('stopTimerBtn');
const timerDisplay = document.getElementById('timerDisplay');

let timerInterval = null;
let timerRunning = false;
let remainingSeconds = 0;

// Function to update simple timer display
function updateTimerDisplay() {
    const mins = Math.floor(remainingSeconds / 60);
    const secs = remainingSeconds % 60;
    timerDisplay.textContent = `${formatTime(mins)}:${formatTime(secs)}`;
}

// Function to start the timer
function startTimer() {
    // Get input values
    let minutes = parseInt(timerMinutesInput.value) || 0;
    let seconds = parseInt(timerSecondsInput.value) || 0;

    // Validate input
    if (minutes === 0 && seconds === 0) {
        alert('Please enter a valid time!');
        return;
    }

    // Calculate total seconds
    remainingSeconds = minutes * 60 + seconds;

    // Show timer display and hide input
    timerDisplay.style.display = 'block';
    timerMinutesInput.disabled = true;
    timerSecondsInput.disabled = true;
    startTimerBtn.disabled = true;
    stopTimerBtn.disabled = false;

    timerRunning = true;
    updateTimerDisplay();

    // Update timer every 1000ms
    timerInterval = setInterval(function() {
        remainingSeconds--;

        if (remainingSeconds < 0) {
            // Timer finished
            clearInterval(timerInterval);
            timerRunning = false;
            timerDisplay.textContent = '00:00';
            timerDisplay.style.color = '#ff6b6b';
            countdownStatus.textContent = '⏱️ Timer Finished!';

            // Alert user
            alert('Timer finished!');

            // Reset controls
            resetTimer();
            return;
        }

        updateTimerDisplay();
    }, 1000);
}

// Function to stop the timer
function stopTimer() {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerRunning = false;
    }
    resetTimer();
}

// Function to reset timer controls
function resetTimer() {
    timerDisplay.style.display = 'none';
    timerDisplay.style.color = '#00ff88';
    timerMinutesInput.disabled = false;
    timerSecondsInput.disabled = false;
    startTimerBtn.disabled = false;
    stopTimerBtn.disabled = true;
    timerMinutesInput.value = '5';
    timerSecondsInput.value = '0';
}

// Add event listeners to timer buttons
startTimerBtn.addEventListener('click', startTimer);
stopTimerBtn.addEventListener('click', stopTimer);

// Allow Enter key to start timer
timerMinutesInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') startTimer();
});

timerSecondsInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') startTimer();
});
