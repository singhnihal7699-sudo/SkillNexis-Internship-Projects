// DOM Elements
const galleryItems = document.querySelectorAll('.gallery-item img');
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightbox-image');
const closeBtn = document.querySelector('.close');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const currentImageSpan = document.getElementById('current-image');
const totalImagesSpan = document.getElementById('total-images');

// Gallery Data
let currentImageIndex = 0;
const totalImages = galleryItems.length;

// Set total images count
totalImagesSpan.textContent = totalImages;

// Open lightbox when clicking on an image
galleryItems.forEach((img, index) => {
    img.addEventListener('click', function() {
        openLightbox(index);
    });
});

// Function to open lightbox
function openLightbox(index) {
    currentImageIndex = index;
    const imageSrc = galleryItems[index].src;
    lightboxImage.src = imageSrc;
    lightbox.classList.add('active');
    currentImageSpan.textContent = index + 1;
    document.body.style.overflow = 'hidden'; // Prevent scrolling
}

// Function to close lightbox
function closeLightbox() {
    lightbox.classList.remove('active');
    document.body.style.overflow = 'auto'; // Re-enable scrolling
}

// Function to show next image
function showNextImage() {
    currentImageIndex = (currentImageIndex + 1) % totalImages;
    const imageSrc = galleryItems[currentImageIndex].src;
    lightboxImage.src = imageSrc;
    currentImageSpan.textContent = currentImageIndex + 1;
}

// Function to show previous image
function showPrevImage() {
    currentImageIndex = (currentImageIndex - 1 + totalImages) % totalImages;
    const imageSrc = galleryItems[currentImageIndex].src;
    lightboxImage.src = imageSrc;
    currentImageSpan.textContent = currentImageIndex + 1;
}

// Close button click event
closeBtn.addEventListener('click', closeLightbox);

// Next button click event
nextBtn.addEventListener('click', showNextImage);

// Previous button click event
prevBtn.addEventListener('click', showPrevImage);

// Close lightbox when clicking outside the image
lightbox.addEventListener('click', function(event) {
    if (event.target === lightbox) {
        closeLightbox();
    }
});

// Keyboard navigation
document.addEventListener('keydown', function(event) {
    if (!lightbox.classList.contains('active')) return;

    switch(event.key) {
        case 'ArrowRight':
            showNextImage();
            event.preventDefault();
            break;
        case 'ArrowLeft':
            showPrevImage();
            event.preventDefault();
            break;
        case 'Escape':
            closeLightbox();
            event.preventDefault();
            break;
    }
});

// Touch support for mobile devices
let touchStartX = 0;
let touchEndX = 0;

lightbox.addEventListener('touchstart', function(event) {
    touchStartX = event.changedTouches[0].screenX;
}, false);

lightbox.addEventListener('touchend', function(event) {
    touchEndX = event.changedTouches[0].screenX;
    handleSwipe();
}, false);

function handleSwipe() {
    const threshold = 50; // Minimum distance for swipe
    const diff = touchStartX - touchEndX;

    if (Math.abs(diff) > threshold) {
        if (diff > 0) {
            // Swiped left - show next image
            showNextImage();
        } else {
            // Swiped right - show previous image
            showPrevImage();
        }
    }
}
