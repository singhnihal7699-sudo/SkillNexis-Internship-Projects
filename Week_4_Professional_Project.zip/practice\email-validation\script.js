// DOM Elements
const emailInput = document.getElementById('email');
const emailFeedback = document.getElementById('emailFeedback');
const resultIcon = document.getElementById('resultIcon');
const resultText = document.getElementById('resultText');
const exampleButtons = document.querySelectorAll('.btn-example');

// Validation rules elements
const rules = {
    length: document.getElementById('rule-length'),
    at: document.getElementById('rule-at'),
    domain: document.getElementById('rule-domain'),
    start: document.getElementById('rule-start'),
    noSpaces: document.getElementById('rule-no-spaces')
};

// Email validation function
function validateEmail(email) {
    const validations = {
        length: email.length >= 5 && email.length <= 50,
        at: (email.match(/@/g) || []).length === 1,
        domain: /\.[a-z]{2,}$/i.test(email),
        start: /^[a-z0-9]/i.test(email),
        noSpaces: !/\s/.test(email)
    };

    // Overall regex validation
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const isValid = emailRegex.test(email) && Object.values(validations).every(v => v);

    return { isValid, validations };
}

// Update UI based on validation
function updateValidationUI(email) {
    if (!email) {
        resetUI();
        return;
    }

    const { isValid, validations } = validateEmail(email);

    // Update input styling
    emailInput.classList.remove('valid', 'invalid');
    emailInput.classList.add(isValid ? 'valid' : 'invalid');

    // Update feedback
    emailFeedback.className = 'feedback ' + (isValid ? 'valid' : 'invalid');
    emailFeedback.textContent = isValid
        ? '✓ Valid email address'
        : '✗ Invalid email address';

    // Update individual rules
    updateRule(rules.length, validations.length);
    updateRule(rules.at, validations.at);
    updateRule(rules.domain, validations.domain);
    updateRule(rules.start, validations.start);
    updateRule(rules.noSpaces, validations.noSpaces);

    // Update result display
    resultIcon.textContent = isValid ? '✅' : '❌';
    resultText.textContent = isValid
        ? `"${email}" is a valid email!`
        : `"${email}" is not a valid email`;
}

// Update individual rule styling
function updateRule(ruleElement, isPassing) {
    ruleElement.classList.remove('pass', 'fail');
    ruleElement.classList.add(isPassing ? 'pass' : 'fail');

    const icon = ruleElement.querySelector('.rule-icon');
    icon.textContent = isPassing ? '✅' : '❌';
}

// Reset UI to initial state
function resetUI() {
    emailInput.classList.remove('valid', 'invalid');
    emailFeedback.className = 'feedback';
    emailFeedback.textContent = '';

    // Reset all rules
    Object.values(rules).forEach(rule => {
        rule.classList.remove('pass', 'fail');
        rule.querySelector('.rule-icon').textContent = '⭕';
    });

    // Reset result display
    resultIcon.textContent = '✉️';
    resultText.textContent = 'Enter an email to validate';
}

// Event Listeners
emailInput.addEventListener('input', (e) => {
    updateValidationUI(e.target.value.trim());
});

// Example buttons
exampleButtons.forEach(button => {
    button.addEventListener('click', () => {
        const email = button.getAttribute('data-email');
        emailInput.value = email;
        updateValidationUI(email);
    });
});

// Initialize
resetUI();
