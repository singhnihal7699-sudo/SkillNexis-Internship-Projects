// Student Management System
class StudentManagement {
    constructor() {
        this.students = this.loadStudents();
        this.currentEditId = null;
        this.currentDeleteId = null;
        this.init();
    }

    init() {
        this.cacheDOM();
        this.bindEvents();
        this.renderStudents();
        this.updateStatistics();
    }

    cacheDOM() {
        // Buttons
        this.addStudentBtn = document.getElementById('addStudentBtn');
        this.closeModal = document.getElementById('closeModal');
        this.cancelBtn = document.getElementById('cancelBtn');
        this.closeDeleteModal = document.getElementById('closeDeleteModal');
        this.cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
        this.confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

        // Modals
        this.studentModal = document.getElementById('studentModal');
        this.deleteModal = document.getElementById('deleteModal');
        this.modalTitle = document.getElementById('modalTitle');
        this.submitBtn = document.getElementById('submitBtn');

        // Form
        this.studentForm = document.getElementById('studentForm');
        this.studentName = document.getElementById('studentName');
        this.studentEmail = document.getElementById('studentEmail');
        this.studentCourse = document.getElementById('studentCourse');
        this.studentGrade = document.getElementById('studentGrade');
        this.studentStatus = document.getElementById('studentStatus');

        // Table
        this.studentsTableBody = document.getElementById('studentsTableBody');
        this.emptyState = document.getElementById('emptyState');

        // Search and Filter
        this.searchInput = document.getElementById('searchInput');
        this.courseFilter = document.getElementById('courseFilter');
        this.statusFilter = document.getElementById('statusFilter');

        // Statistics
        this.totalStudentsEl = document.getElementById('totalStudents');
        this.activeStudentsEl = document.getElementById('activeStudents');
        this.averageGradeEl = document.getElementById('averageGrade');
        this.topPerformersEl = document.getElementById('topPerformers');

        // Notification
        this.notification = document.getElementById('notification');
    }

    bindEvents() {
        this.addStudentBtn.addEventListener('click', () => this.openAddModal());
        this.closeModal.addEventListener('click', () => this.closeStudentModal());
        this.cancelBtn.addEventListener('click', () => this.closeStudentModal());
        this.studentForm.addEventListener('submit', (e) => this.handleSubmit(e));

        this.closeDeleteModal.addEventListener('click', () => this.closeDeleteConfirmModal());
        this.cancelDeleteBtn.addEventListener('click', () => this.closeDeleteConfirmModal());
        this.confirmDeleteBtn.addEventListener('click', () => this.confirmDelete());

        this.searchInput.addEventListener('input', () => this.filterStudents());
        this.courseFilter.addEventListener('change', () => this.filterStudents());
        this.statusFilter.addEventListener('change', () => this.filterStudents());

        // Close modal on outside click
        this.studentModal.addEventListener('click', (e) => {
            if (e.target === this.studentModal) {
                this.closeStudentModal();
            }
        });

        this.deleteModal.addEventListener('click', (e) => {
            if (e.target === this.deleteModal) {
                this.closeDeleteConfirmModal();
            }
        });
    }

    // LocalStorage operations
    loadStudents() {
        const stored = localStorage.getItem('students');
        return stored ? JSON.parse(stored) : [];
    }

    saveStudents() {
        localStorage.setItem('students', JSON.stringify(this.students));
    }

    // Generate unique ID
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    // Modal operations
    openAddModal() {
        this.currentEditId = null;
        this.modalTitle.textContent = 'Add New Student';
        this.submitBtn.textContent = 'Add Student';
        this.studentForm.reset();
        this.studentModal.classList.add('show');
    }

    openEditModal(id) {
        this.currentEditId = id;
        const student = this.students.find(s => s.id === id);

        if (student) {
            this.modalTitle.textContent = 'Edit Student';
            this.submitBtn.textContent = 'Update Student';
            this.studentName.value = student.name;
            this.studentEmail.value = student.email;
            this.studentCourse.value = student.course;
            this.studentGrade.value = student.grade;
            this.studentStatus.value = student.status;
            this.studentModal.classList.add('show');
        }
    }

    closeStudentModal() {
        this.studentModal.classList.remove('show');
        this.studentForm.reset();
        this.currentEditId = null;
    }

    openDeleteConfirmModal(id) {
        this.currentDeleteId = id;
        this.deleteModal.classList.add('show');
    }

    closeDeleteConfirmModal() {
        this.deleteModal.classList.remove('show');
        this.currentDeleteId = null;
    }

    // CRUD operations
    handleSubmit(e) {
        e.preventDefault();

        const studentData = {
            name: this.studentName.value.trim(),
            email: this.studentEmail.value.trim(),
            course: this.studentCourse.value,
            grade: parseInt(this.studentGrade.value),
            status: this.studentStatus.value
        };

        if (this.currentEditId) {
            this.updateStudent(this.currentEditId, studentData);
        } else {
            this.addStudent(studentData);
        }
    }

    addStudent(data) {
        const student = {
            id: this.generateId(),
            ...data,
            createdAt: new Date().toISOString()
        };

        this.students.unshift(student);
        this.saveStudents();
        this.renderStudents();
        this.updateStatistics();
        this.closeStudentModal();
        this.showNotification('Student added successfully!', 'success');
    }

    updateStudent(id, data) {
        const index = this.students.findIndex(s => s.id === id);

        if (index !== -1) {
            this.students[index] = {
                ...this.students[index],
                ...data,
                updatedAt: new Date().toISOString()
            };

            this.saveStudents();
            this.renderStudents();
            this.updateStatistics();
            this.closeStudentModal();
            this.showNotification('Student updated successfully!', 'success');
        }
    }

    confirmDelete() {
        if (this.currentDeleteId) {
            this.deleteStudent(this.currentDeleteId);
        }
    }

    deleteStudent(id) {
        this.students = this.students.filter(s => s.id !== id);
        this.saveStudents();
        this.renderStudents();
        this.updateStatistics();
        this.closeDeleteConfirmModal();
        this.showNotification('Student deleted successfully!', 'success');
    }

    // Render operations
    renderStudents(studentsToRender = this.students) {
        if (studentsToRender.length === 0) {
            this.studentsTableBody.innerHTML = '';
            this.emptyState.classList.add('show');
            return;
        }

        this.emptyState.classList.remove('show');

        this.studentsTableBody.innerHTML = studentsToRender.map(student => `
            <tr>
                <td><span class="student-id">#${student.id.substr(0, 6)}</span></td>
                <td><span class="student-name">${this.escapeHtml(student.name)}</span></td>
                <td><span class="student-email">${this.escapeHtml(student.email)}</span></td>
                <td>${this.escapeHtml(student.course)}</td>
                <td><span class="grade-badge ${this.getGradeClass(student.grade)}">${student.grade}</span></td>
                <td><span class="status-badge status-${student.status.toLowerCase()}">${student.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-icon btn-edit" onclick="app.openEditModal('${student.id}')" title="Edit">
                            ✏️
                        </button>
                        <button class="btn-icon btn-delete" onclick="app.openDeleteConfirmModal('${student.id}')" title="Delete">
                            🗑️
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Filter and search
    filterStudents() {
        const searchTerm = this.searchInput.value.toLowerCase();
        const courseFilter = this.courseFilter.value;
        const statusFilter = this.statusFilter.value;

        let filtered = this.students;

        // Search
        if (searchTerm) {
            filtered = filtered.filter(student =>
                student.name.toLowerCase().includes(searchTerm) ||
                student.email.toLowerCase().includes(searchTerm) ||
                student.course.toLowerCase().includes(searchTerm)
            );
        }

        // Course filter
        if (courseFilter) {
            filtered = filtered.filter(student => student.course === courseFilter);
        }

        // Status filter
        if (statusFilter) {
            filtered = filtered.filter(student => student.status === statusFilter);
        }

        this.renderStudents(filtered);
    }

    // Statistics
    updateStatistics() {
        const total = this.students.length;
        const active = this.students.filter(s => s.status === 'Active').length;
        const avgGrade = total > 0
            ? Math.round(this.students.reduce((sum, s) => sum + s.grade, 0) / total)
            : 0;
        const topPerformers = this.students.filter(s => s.grade >= 90).length;

        this.totalStudentsEl.textContent = total;
        this.activeStudentsEl.textContent = active;
        this.averageGradeEl.textContent = avgGrade;
        this.topPerformersEl.textContent = topPerformers;
    }

    // Helper functions
    getGradeClass(grade) {
        if (grade >= 90) return 'grade-excellent';
        if (grade >= 75) return 'grade-good';
        if (grade >= 60) return 'grade-average';
        return 'grade-poor';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showNotification(message, type) {
        this.notification.textContent = message;
        this.notification.className = `notification ${type} show`;

        setTimeout(() => {
            this.notification.classList.remove('show');
        }, 3000);
    }
}

// Initialize the app
const app = new StudentManagement();

// Add some sample data if localStorage is empty
if (app.students.length === 0) {
    const sampleStudents = [
        {
            id: app.generateId(),
            name: 'Alice Johnson',
            email: 'alice.j@university.edu',
            course: 'Computer Science',
            grade: 92,
            status: 'Active',
            createdAt: new Date().toISOString()
        },
        {
            id: app.generateId(),
            name: 'Bob Smith',
            email: 'bob.smith@university.edu',
            course: 'Mathematics',
            grade: 88,
            status: 'Active',
            createdAt: new Date().toISOString()
        },
        {
            id: app.generateId(),
            name: 'Carol Williams',
            email: 'carol.w@university.edu',
            course: 'Physics',
            grade: 95,
            status: 'Active',
            createdAt: new Date().toISOString()
        },
        {
            id: app.generateId(),
            name: 'David Brown',
            email: 'david.b@university.edu',
            course: 'Chemistry',
            grade: 78,
            status: 'Inactive',
            createdAt: new Date().toISOString()
        },
        {
            id: app.generateId(),
            name: 'Emma Davis',
            email: 'emma.d@university.edu',
            course: 'Biology',
            grade: 85,
            status: 'Active',
            createdAt: new Date().toISOString()
        }
    ];

    app.students = sampleStudents;
    app.saveStudents();
    app.renderStudents();
    app.updateStatistics();
}
