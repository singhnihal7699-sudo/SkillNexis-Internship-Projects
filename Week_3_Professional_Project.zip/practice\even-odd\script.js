// DOM Elements
const numberInput = document.getElementById('numberInput');
const checkBtn = document.getElementById('checkBtn');
const result = document.getElementById('result');
const exampleButtons = document.querySelectorAll('.btn-example');

// Main function to check if number is even or odd
function checkEvenOrOdd(number) {
    // Validate input
    if (number === '' || number === null || number === undefined) {
        return { type: 'error', message: 'Please enter a number!' };
    }

    const num = Number(number);

    if (isNaN(num)) {
        return { type: 'error', message: 'Please enter a valid number!' };
    }

    // Check if even or odd using modulo operator
    if (num % 2 === 0) {
        return {
            type: 'even',
            message: `${num} is an EVEN number! ✓`
        };
    } else {
        return {
            type: 'odd',
            message: `${num} is an ODD number! ✓`
        };
    }
}

// Display result
function displayResult(resultData) {
    result.className = 'result ' + resultData.type;
    result.textContent = resultData.message;
}

// Event listener for check button
checkBtn.addEventListener('click', () => {
    const value = numberInput.value.trim();
    const resultData = checkEvenOrOdd(value);
    displayResult(resultData);
});

// Event listener for Enter key
numberInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        const value = numberInput.value.trim();
        const resultData = checkEvenOrOdd(value);
        displayResult(resultData);
    }
});

// Event listeners for example buttons
exampleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        const num = btn.getAttribute('data-num');
        numberInput.value = num;
        const resultData = checkEvenOrOdd(num);
        displayResult(resultData);
    });
});

// Clear result when input changes
numberInput.addEventListener('input', () => {
    result.className = 'result';
    result.textContent = '';
});
