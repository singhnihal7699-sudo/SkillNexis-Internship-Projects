// DOM Elements
const dayName = document.getElementById('dayName');
const dateNumber = document.getElementById('dateNumber');
const monthYear = document.getElementById('monthYear');
const currentTime = document.getElementById('currentTime');
const fullDate = document.getElementById('fullDate');
const dayOfYear = document.getElementById('dayOfYear');
const weekNumber = document.getElementById('weekNumber');
const timeZone = document.getElementById('timeZone');
const isoFormat = document.getElementById('isoFormat');
const utcFormat = document.getElementById('utcFormat');
const unixFormat = document.getElementById('unixFormat');

// Arrays for day and month names
const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December'];

// Calculate day of year
function getDayOfYear(date) {
    const start = new Date(date.getFullYear(), 0, 0);
    const diff = date - start;
    const oneDay = 1000 * 60 * 60 * 24;
    return Math.floor(diff / oneDay);
}

// Calculate week number
function getWeekNumber(date) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// Format time with leading zeros
function formatTime(hours, minutes, seconds) {
    const h = hours.toString().padStart(2, '0');
    const m = minutes.toString().padStart(2, '0');
    const s = seconds.toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
}

// Update all date and time displays
function updateDateTime() {
    const now = new Date();

    // Main date display
    dayName.textContent = dayNames[now.getDay()];
    dateNumber.textContent = now.getDate();
    monthYear.textContent = `${monthNames[now.getMonth()]} ${now.getFullYear()}`;

    // Current time
    currentTime.textContent = formatTime(now.getHours(), now.getMinutes(), now.getSeconds());

    // Full date
    fullDate.textContent = now.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    // Day of year
    dayOfYear.textContent = `Day ${getDayOfYear(now)}`;

    // Week number
    weekNumber.textContent = `Week ${getWeekNumber(now)}`;

    // Time zone
    const tzOffset = -now.getTimezoneOffset() / 60;
    const tzSign = tzOffset >= 0 ? '+' : '';
    timeZone.textContent = `UTC${tzSign}${tzOffset}`;

    // ISO format
    isoFormat.textContent = now.toISOString();

    // UTC format
    utcFormat.textContent = now.toUTCString();

    // Unix timestamp
    unixFormat.textContent = Math.floor(now.getTime() / 1000);
}

// Update immediately
updateDateTime();

// Update every second
setInterval(updateDateTime, 1000);
