// DOM Elements
const previousDisplay = document.getElementById('previousDisplay');
const currentDisplay = document.getElementById('currentDisplay');
const numberButtons = document.querySelectorAll('[data-number]');
const operatorButtons = document.querySelectorAll('[data-operator]');
const equalsButton = document.querySelector('[data-action="equals"]');
const clearButton = document.querySelector('[data-action="clear"]');
const deleteButton = document.querySelector('[data-action="delete"]');
const decimalButton = document.querySelector('[data-action="decimal"]');

// Calculator state
let currentValue = '0';
let previousValue = '';
let operation = null;
let shouldResetDisplay = false;

// Update display
function updateDisplay() {
    currentDisplay.textContent = currentValue;
    if (operation && previousValue) {
        previousDisplay.textContent = `${previousValue} ${getOperatorSymbol(operation)}`;
    } else {
        previousDisplay.textContent = '';
    }
}

// Get operator symbol
function getOperatorSymbol(op) {
    const symbols = {
        '+': '+',
        '-': '−',
        '*': '×',
        '/': '÷',
        '%': '%'
    };
    return symbols[op] || op;
}

// Append number
function appendNumber(number) {
    if (shouldResetDisplay) {
        currentValue = number;
        shouldResetDisplay = false;
    } else {
        if (currentValue === '0') {
            currentValue = number;
        } else {
            currentValue += number;
        }
    }
    updateDisplay();
}

// Append decimal
function appendDecimal() {
    if (shouldResetDisplay) {
        currentValue = '0.';
        shouldResetDisplay = false;
    } else if (!currentValue.includes('.')) {
        currentValue += '.';
    }
    updateDisplay();
}

// Choose operation
function chooseOperation(operator) {
    if (currentValue === '') return;

    if (previousValue !== '') {
        calculate();
    }

    operation = operator;
    previousValue = currentValue;
    shouldResetDisplay = true;
    updateDisplay();
}

// Calculate result
function calculate() {
    let result;
    const prev = parseFloat(previousValue);
    const current = parseFloat(currentValue);

    if (isNaN(prev) || isNaN(current)) return;

    switch (operation) {
        case '+':
            result = prev + current;
            break;
        case '-':
            result = prev - current;
            break;
        case '*':
            result = prev * current;
            break;
        case '/':
            if (current === 0) {
                currentValue = 'Error';
                previousValue = '';
                operation = null;
                updateDisplay();
                setTimeout(() => {
                    clear();
                }, 1500);
                return;
            }
            result = prev / current;
            break;
        case '%':
            result = prev % current;
            break;
        default:
            return;
    }

    // Round to avoid floating point errors
    result = Math.round(result * 100000000) / 100000000;

    currentValue = result.toString();
    operation = null;
    previousValue = '';
    updateDisplay();
}

// Clear all
function clear() {
    currentValue = '0';
    previousValue = '';
    operation = null;
    shouldResetDisplay = false;
    updateDisplay();
}

// Delete last digit
function deleteDigit() {
    if (currentValue.length === 1 || currentValue === '0') {
        currentValue = '0';
    } else {
        currentValue = currentValue.slice(0, -1);
    }
    updateDisplay();
}

// Event Listeners
numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        appendNumber(button.dataset.number);
    });
});

operatorButtons.forEach(button => {
    button.addEventListener('click', () => {
        chooseOperation(button.dataset.operator);
    });
});

equalsButton.addEventListener('click', calculate);
clearButton.addEventListener('click', clear);
deleteButton.addEventListener('click', deleteDigit);
decimalButton.addEventListener('click', appendDecimal);

// Keyboard support
document.addEventListener('keydown', (e) => {
    if (e.key >= '0' && e.key <= '9') {
        appendNumber(e.key);
    } else if (e.key === '.') {
        appendDecimal();
    } else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
        chooseOperation(e.key);
    } else if (e.key === '%') {
        chooseOperation('%');
    } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        calculate();
    } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        clear();
    } else if (e.key === 'Backspace') {
        deleteDigit();
    }
});

// Initialize
updateDisplay();
