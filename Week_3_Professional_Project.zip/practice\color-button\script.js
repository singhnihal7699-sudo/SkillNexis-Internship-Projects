// DOM Elements
const colorBtn = document.getElementById('colorBtn');
const colorName = document.getElementById('colorName');
const clickCount = document.getElementById('clickCount');
const resetBtn = document.getElementById('resetBtn');
const randomBtn = document.getElementById('randomBtn');
const colorSwatches = document.querySelectorAll('.color-swatch');

// Color palette
const colors = [
    { color: '#667eea', name: 'Purple' },
    { color: '#f56565', name: 'Red' },
    { color: '#48bb78', name: 'Green' },
    { color: '#ed8936', name: 'Orange' },
    { color: '#4299e1', name: 'Blue' },
    { color: '#9f7aea', name: 'Violet' },
    { color: '#ed64a6', name: 'Pink' },
    { color: '#38b2ac', name: 'Teal' }
];

let currentIndex = 0;
let clicks = 0;

// Change to next color
function changeColor() {
    currentIndex = (currentIndex + 1) % colors.length;
    const selected = colors[currentIndex];

    colorBtn.style.background = selected.color;
    colorBtn.style.boxShadow = `0 8px 25px ${selected.color}66`;
    colorName.textContent = selected.name;
    colorName.style.color = selected.color;

    clicks++;
    clickCount.textContent = clicks;

    // Update active swatch
    updateActiveSwatch();
}

// Change to specific color
function changeToColor(index) {
    currentIndex = index;
    const selected = colors[currentIndex];

    colorBtn.style.background = selected.color;
    colorBtn.style.boxShadow = `0 8px 25px ${selected.color}66`;
    colorName.textContent = selected.name;
    colorName.style.color = selected.color;

    clicks++;
    clickCount.textContent = clicks;

    updateActiveSwatch();
}

// Reset to default
function resetColors() {
    currentIndex = 0;
    const selected = colors[currentIndex];

    colorBtn.style.background = selected.color;
    colorBtn.style.boxShadow = `0 8px 25px rgba(102, 126, 234, 0.4)`;
    colorName.textContent = selected.name;
    colorName.style.color = '#2d3748';
    clicks = 0;
    clickCount.textContent = '0';

    updateActiveSwatch();
}

// Get random color
function randomColor() {
    const randomIndex = Math.floor(Math.random() * colors.length);
    changeToColor(randomIndex);
}

// Update active swatch
function updateActiveSwatch() {
    colorSwatches.forEach((swatch, index) => {
        swatch.classList.toggle('active', index === currentIndex);
    });
}

// Event Listeners
colorBtn.addEventListener('click', changeColor);

resetBtn.addEventListener('click', resetColors);

randomBtn.addEventListener('click', randomColor);

// Color swatch clicks
colorSwatches.forEach((swatch, index) => {
    swatch.addEventListener('click', () => {
        changeToColor(index);
    });
});