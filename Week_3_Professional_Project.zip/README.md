# Week 3 - JavaScript Logic & APIs

## 📋 Project Overview

This project contains all assignments and practice questions for Week 3 of the Web Development course, focusing on JavaScript fundamentals, DOM manipulation, and API integration.

## 🎯 Learning Objectives

- Master JavaScript fundamentals (variables, functions, loops)
- Understand DOM manipulation and event handling
- Integrate external APIs using Fetch
- Parse and display JSON data
- Build interactive web applications

## 📁 Project Structure

```
Week 3/
├── index.html              # Main landing page
├── README.md              # This file
├── assets/
│   └── main.css           # Landing page styles
├── weather-app/           # Main Assignment
│   ├── index.html
│   ├── style.css
│   └── script.js
└── practice/              # Practice Questions
    ├── even-odd/          # Question 1: Even/Odd Checker
    ├── color-button/      # Question 2: Color-Changing Button
    ├── calculator/        # Question 3: Simple Calculator
    └── dynamic-date/      # Question 4: Dynamic Date Display
```

## 🚀 Main Assignment

### Weather App (OpenWeatherMap API)

**Features:**
- City search functionality
- Real-time weather data fetching
- Temperature, humidity, and weather condition display
- Wind speed and pressure information
- Professional card-based UI
- Error handling for invalid cities
- Loading states
- Responsive design

**Technologies:**
- HTML5
- CSS3 (Gradients, Flexbox, Grid)
- JavaScript ES6
- Fetch API
- OpenWeatherMap API
- JSON parsing

**API Configuration:**
- API endpoint: `https://api.openweathermap.org/data/2.5/weather`
- API key is included in the code for demonstration purposes
- Free tier API key with sufficient quota for testing

## 📝 Practice Questions

### 1. Even/Odd Number Checker

**Description:** JavaScript function to check if a number is even or odd.

**Features:**
- Input validation
- Real-time checking
- Visual feedback (different colors for even/odd)
- Quick example buttons
- Keyboard support (Enter key)

### 2. Color-Changing Button

**Description:** Interactive button that changes color on click.

**Features:**
- 8 predefined color palette
- Click counter
- Random color generator
- Reset functionality
- Color swatch selection
- Smooth transitions and animations

### 3. Simple Calculator

**Description:** Basic calculator with arithmetic operations.

**Features:**
- Addition, subtraction, multiplication, division, modulo
- Keyboard support (number keys, operators, Enter, Backspace, Escape)
- Clear and delete functions
- Decimal point support
- Division by zero error handling
- Professional calculator UI
- Previous and current operation display

### 4. Dynamic Date Display

**Description:** Display today's date dynamically on webpage.

**Features:**
- Live date and time display
- Multiple date formats (ISO, UTC, Unix timestamp)
- Day of year calculation
- Week number calculation
- Time zone display
- Updates every second
- Professional typography and layout

## 🛠️ Technologies Used

- **HTML5**: Semantic markup
- **CSS3**: 
  - Flexbox and Grid layouts
  - CSS animations and transitions
  - Gradient backgrounds
  - Responsive design
  - Modern card-based UI
- **JavaScript ES6**:
  - Arrow functions
  - Template literals
  - Const and let
  - Array methods
  - Async/await with Fetch API
  - DOM manipulation
  - Event listeners
  - Date and Math objects

## 💻 How to Run

1. **Download/Extract** the Week 3 folder
2. **Open** `index.html` in a modern web browser
3. **Navigate** to different projects from the landing page
4. **For Weather App**: Enter any city name and click "Get Weather"
5. **For Practice Questions**: Follow the instructions on each page

### Requirements

- Modern web browser (Chrome, Firefox, Edge, Safari)
- Internet connection (for Weather App API calls)
- No additional dependencies or installations required

## 🌐 API Information

### OpenWeatherMap API

The Weather App uses the OpenWeatherMap API to fetch real-time weather data.

- **Endpoint**: `https://api.openweathermap.org/data/2.5/weather`
- **Method**: GET
- **Parameters**: 
  - `q`: City name
  - `appid`: API key
  - `units`: metric (for Celsius)

**Sample Response:**
```json
{
  "name": "London",
  "sys": { "country": "GB" },
  "main": {
    "temp": 15.5,
    "feels_like": 14.2,
    "humidity": 72,
    "pressure": 1013
  },
  "weather": [
    {
      "main": "Clouds",
      "description": "broken clouds"
    }
  ],
  "wind": {
    "speed": 5.2
  }
}
```

## ✅ Testing Checklist

### Weather App
- [x] City search works
- [x] Temperature displays correctly
- [x] Humidity shows
- [x] Weather condition displays
- [x] Wind speed and pressure display
- [x] Error handling for invalid cities
- [x] Loading spinner appears
- [x] Responsive on mobile
- [x] API fetching works

### Practice Question 1
- [x] Even numbers detected correctly
- [x] Odd numbers detected correctly
- [x] Input validation works
- [x] Visual feedback displays
- [x] Example buttons work

### Practice Question 2
- [x] Button changes color on click
- [x] Color palette works
- [x] Random color generator works
- [x] Click counter increments
- [x] Reset button works

### Practice Question 3
- [x] Basic operations (+ - × ÷) work
- [x] Decimal points work
- [x] Clear function works
- [x] Delete function works
- [x] Division by zero handled
- [x] Keyboard support works

### Practice Question 4
- [x] Date displays dynamically
- [x] Time updates every second
- [x] Multiple date formats shown
- [x] Day of year calculated
- [x] Week number calculated
- [x] Time zone displayed

## 🎨 Design Features

- **Professional UI**: Modern, clean, portfolio-ready design
- **Consistent Theme**: Purple gradient theme across all projects
- **Responsive**: Works on desktop, tablet, and mobile
- **Animations**: Smooth transitions and hover effects
- **Typography**: Professional font hierarchy
- **Colors**: Carefully chosen color palette
- **Spacing**: Consistent padding and margins
- **Shadows**: Subtle depth and elevation

## 📚 Skills Gained

1. **API Integration**: Fetch data from external APIs
2. **JSON Parsing**: Parse and display JSON data
3. **DOM Manipulation**: Create, modify, and delete DOM elements
4. **Event Handling**: Handle click, input, and keyboard events
5. **Error Handling**: Handle API errors and invalid inputs
6. **Async JavaScript**: Use async/await for API calls
7. **Functions**: Create reusable JavaScript functions
8. **Validation**: Validate user inputs
9. **Date/Time**: Work with Date objects
10. **Responsive Design**: Build mobile-friendly layouts

## 🔮 Future Improvements

- Add weather forecast for multiple days
- Implement geolocation for automatic city detection
- Add more calculator functions (square root, percentage)
- Store favorite cities in localStorage
- Add dark mode toggle
- Implement more sophisticated date formatting options

## 👨‍💻 Author

Web Development Course - Week 3 Assignment
Created: September 2026

## 📄 License

This project is created for educational purposes as part of the Web Development course.
